#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;
int main() {
int total ,randomnumber2 ;
string start ,rollagain ;
cout<<"Welcome to Craps \n     ⚀⚁⚂⚃⚄⚅\nWould you like to play Y/N \n" ;
cin>>start;
if ((start=="Y") || (start=="y")) {
srand ((unsigned) time (0));
int randomnumber = (rand () % 12+2) ;
if ((randomnumber==7) || (randomnumber==11)){
//generates number between 2-12 since 2 dice make a result between 2 and 12. then tell the user if they won , lost , or can roll again on there second roll 
cout<<"Winner !!!" ;
}else if ((randomnumber==2) || (randomnumber==12)){
  cout<<"Sorry you lose" ;
} else {
  cout<<"you rolled "<<randomnumber<<"\n type R to roll again \n" ;
cin>>rollagain;
if ((rollagain=="R") || (rollagain=="r")){
while(randomnumber2!=randomnumber){
srand ((unsigned) time (0));
 randomnumber2 = (rand () % 12+2) ;
cout<<"you rolled "<<randomnumber2<<"\n" ;
cin>>rollagain;
}
} else if (randomnumber2==randomnumber) {
  cout<<"Winner !!" ;
} else if ((randomnumber2==7) || (randomnumber==11)){
  cout<<"Sorry you lose" ;
}else {
  cout<<"error" ;
}
}
}
else if ((start=="N") || (start=="n")) {
  cout<<"Goodbye ( ﾟ▽ﾟﾟ)/ ";
}else {
  cout<<"error";
}
}